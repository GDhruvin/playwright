import { test, expect } from '@playwright/experimental-ct-react';
import App from '../App';
import ProcessViewer from '../ProcessViewer';
import { WeatherComponent } from '../modules/WeatherInfoComponent.js';
import { CityComponent } from '../modules/CityComponent';
import Counter from '../modules/Counter.js'

//Imports the App component to test from the relative ../App path


//Configures the viewport to a 500x500 size
test.use({ viewport: { width: 500, height: 500 } });
//Starts a test case named "should work" which will run asynchronously,
//mount function binding is destructured from test parameter
test('should work', async ({ mount }) => {
    //Uses mount() to instantiate the <App /> component in isolation
    const component = await mount(<App />);
    //Asserts that component contains expected "Learn React" text on it verifying basic render.
    await expect(component).toContainText('Learn React');
});

test('this will work', async ({ mount }) => {
    const component = await mount(<ProcessViewer process={{ name: 'playwright' }} />);
    await expect(component).toContainText('playwright');
});

test('WeatherInfo accepts name and value', async ({ mount }) => {
    const weatherInfo = { "coord": { "lon": 105.8412, "lat": 21.0245 }, "weather": [{ "id": 800, "main": "Clear", "description": "clear sky", "icon": "01n" }], "base": "stations", "main": { "temp": 302.15, "feels_like": 301.35, "temp_min": 302.15, "temp_max": 302.15, "pressure": 1003, "humidity": 35, "sea_level": 1003, "grnd_level": 1002 }, "visibility": 10000, "wind": { "speed": 2.71, "deg": 73, "gust": 3.29 }, "clouds": { "all": 0 }, "dt": 1673694125, "sys": { "type": 1, "id": 9308, "country": "VN", "sunrise": 1673652961, "sunset": 1673692464 }, "timezone": 25200, "id": 1581130, "name": "Hanoi", "cod": 200 }
    const weatherComponent = await mount(<WeatherComponent
        weather={(weatherInfo)}
    />);
    await expect(weatherComponent).toContainText('Hanoi')
});

const cityLocator = '[placeholder="City"]'
const searchButtonLocator = '[type="submit"]'

const cityName = 'Hanoi'

test('cityField accepts text input', async ({ mount }) => {
    const cityComponent = await mount(<CityComponent />);
    const cityField = cityComponent.locator(cityLocator)

    await cityField.fill(cityName)

    await expect(cityField).toHaveValue(cityName)
});

test('Click on `Search` button executes fetchWeather prop', async ({ mount }) => {
    let isCalled = false
    const cityComponent = await mount(
        <CityComponent
            fetchWeather={() => isCalled = true}
        />
    );

    await cityComponent.locator(cityLocator).fill(cityName)
    await cityComponent.locator(searchButtonLocator).click()

    expect(isCalled).toBeTruthy()
});

test('WeatherComponent displays sunrise/sunset information correctly', async ({ mount }) => {
    const weatherInfo = { "coord": { "lon": 105.8412, "lat": 21.0245 }, "weather": [{ "id": 800, "main": "Clear", "description": "clear sky", "icon": "01n" }], "base": "stations", "main": { "temp": 302.15, "feels_like": 301.35, "temp_min": 302.15, "temp_max": 302.15, "pressure": 1003, "humidity": 35, "sea_level": 1003, "grnd_level": 1002 }, "visibility": 10000, "wind": { "speed": 2.71, "deg": 73, "gust": 3.29 }, "clouds": { "all": 0 }, "dt": 1673694125, "sys": { "type": 1, "id": 9308, "country": "VN", "sunrise": 1673652961, "sunset": 1673692464 }, "timezone": 25200, "id": 1581130, "name": "Hanoi", "cod": 200 }
    const weatherComponent = await mount(<WeatherComponent weather={weatherInfo} />);
    await expect(weatherComponent).toContainText("29°C  |  clear skyHanoi, VNWeather Info5 : 6sunrise35humidity2.71wind1003pressure");
});

test('WeatherComponent displays weather information accurately', async ({ mount }) => {
    const weatherInfo = { "coord": { "lon": 105.8412, "lat": 21.0245 }, "weather": [{ "id": 800, "main": "Clear", "description": "clear sky", "icon": "01n" }], "base": "stations", "main": { "temp": 302.15, "feels_like": 301.35, "temp_min": 302.15, "temp_max": 302.15, "pressure": 1003, "humidity": 35, "sea_level": 1003, "grnd_level": 1002 }, "visibility": 10000, "wind": { "speed": 2.71, "deg": 73, "gust": 3.29 }, "clouds": { "all": 0 }, "dt": 1673694125, "sys": { "type": 1, "id": 9308, "country": "VN", "sunrise": 1673652961, "sunset": 1673692464 }, "timezone": 25200, "id": 1581130, "name": "Hanoi", "cod": 200 }
    const weatherComponent = await mount(<WeatherComponent weather={weatherInfo} />);

    await expect(weatherComponent).toContainText('29°C');
    await expect(weatherComponent).toContainText('35');
    await expect(weatherComponent).toContainText('2.71');
    await expect(weatherComponent).toContainText('1003');
});

// test('should work for counter', async ({ mount }) => {
//     const component = await mount(<Counter></Counter>);
//     await expect(component.getByRole('button')).toBeVisible();
//     await component.getByRole('button', { name: 'Increment' }).click();
// });

const counterSelector = '[data-cy="counter"]';
  const incrementSelector = "[aria-label=increment]";
  const decrementSelector = "[aria-label=decrement]";

test('Two time Increment ', async ({ mount }) => {
  const component = await mount(<Counter />);
  await component.locator(incrementSelector).click();
  await expect(component.locator(counterSelector)).toHaveText('1');
  await component.locator(incrementSelector).click();
  await expect(component.locator(counterSelector)).toHaveText('2');
});

test('Increment then the decrement ', async ({ mount }) => {
  const component = await mount(<Counter />);
  await component.locator(incrementSelector).click();
  await expect(component.locator(counterSelector)).toHaveText('1');
  await component.locator(decrementSelector).click();
  await expect(component.locator(counterSelector)).toHaveText('0');
});