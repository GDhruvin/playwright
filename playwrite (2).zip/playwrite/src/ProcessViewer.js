import './App.css';

function ProcessViewer(props) {
    const name = props.process
  return (
    <div className="App">
        <p>{name.name}</p>
    </div>
  );
}

export default ProcessViewer;