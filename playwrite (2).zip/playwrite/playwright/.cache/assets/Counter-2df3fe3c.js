import { j as jsxRuntimeExports } from './jsx-runtime-ddc3003a.js';
import { r as reactExports } from './index-b5d424d2.js';

function Counter({ initial = 0 }) {
  const [count, setCount] = reactExports.useState(initial);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: {
    padding: 30
  }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("button", { style: { color: "black", backgroundColor: "green", margin: 10 }, "aria-label": "decrement", onClick: () => setCount(count - 1), children: "-" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "data-cy": "counter", children: count }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("button", { style: { color: "black", backgroundColor: "green", margin: 10 }, "aria-label": "increment", onClick: () => setCount(count + 1), children: "+" })
  ] });
}

export { Counter as default };
//# sourceMappingURL=Counter-2df3fe3c.js.map
