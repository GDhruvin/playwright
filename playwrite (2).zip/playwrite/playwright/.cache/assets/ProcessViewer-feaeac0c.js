import { j as jsxRuntimeExports } from './jsx-runtime-ddc3003a.js';
import './index-b5d424d2.js';

const App = '';

function ProcessViewer(props) {
  const name = props.process;
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "App", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: name.name }) });
}

export { ProcessViewer as default };
//# sourceMappingURL=ProcessViewer-feaeac0c.js.map
